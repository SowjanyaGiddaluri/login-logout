import React, {useState} from 'react';
import '../Components/LoginSign.css';

const login = () => {
    const[Action, setAction] = useState("Sign Up");
    const[isLogged, setIsLogged] = useState(false);
    return(
        <div className="container">
            <div>
                
            </div>
        </div>
    )
}
export default login;